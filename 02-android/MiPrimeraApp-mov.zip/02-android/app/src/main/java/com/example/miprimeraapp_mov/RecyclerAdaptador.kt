package com.example.miprimeraapp_mov

class RecyclerAdaptador(){

}