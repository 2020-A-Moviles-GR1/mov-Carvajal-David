package com.example.miprimeraapp_mov

class ServicioBDDMemoria(){
    companion object{
            var numero=0
                fun anadirNumero(){
                this.numero =this.numero+1
                }
    }
}